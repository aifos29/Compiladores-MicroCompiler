Compilar de primero: MicroCompiler.c
       gcc MicroCompiler.c -o micro

Compilar de segundo: microt.c
	gcc microt.c -o traductor

Finalmente compilar: todo.c
	gcc todo.c -o compiler

Para corre el programa, donde file.txt es el archivo que queremos compilar:
 	./compiler file.txt

El codigo generado se almacena en salida.asm


Algunas de las funciones que no funcionan correctamente son:

