
#include <stdio.h>
#include "auxiliar.h"




void main(int argc, char const *argv[]){
	char iniciar[100];
	char traductor[100];
	snprintf(iniciar, sizeof(iniciar), "./micro %s",argv[1]);
	system(iniciar);
	snprintf(traductor, sizeof(traductor), "./traductor %s",argv[1]);
	system(traductor);	
}

